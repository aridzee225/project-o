/**
 * Melindungi halaman yang membutuhkan login.
 * Jika tidak ada sesi aktif, pengguna diarahkan ke halaman login.
 */
supabaseClient.auth.getSession().then(({ data }) => {
    if (!data.session) {
        window.location.href = "login.html";
    }
});
