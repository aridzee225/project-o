/**
 * Halaman registrasi: membuat akun baru dan menyimpan nama tampilan
 * di user metadata (dibaca kembali saat login untuk membuat profil).
 */
const registerForm = document.getElementById("registerForm");
const registerMessage = document.getElementById("registerMessage");

registerForm.addEventListener("submit", async (event) => {
    event.preventDefault();

    const displayName = document.getElementById("displayName").value.trim();
    const email = document.getElementById("email").value.trim();
    const password = document.getElementById("password").value;

    registerMessage.textContent = "Membuat akun...";

    const { data, error } = await supabaseClient.auth.signUp({
        email,
        password,
        options: {
            data: { display_name: displayName },
        },
    });

    if (error) {
        registerMessage.textContent = "Pendaftaran gagal: " + error.message;
        return;
    }

    if (!data.user) {
        registerMessage.textContent =
            "Pendaftaran gagal. User tidak ditemukan.";
        return;
    }

    registerMessage.textContent = "Akun berhasil dibuat! Silakan login.";

    setTimeout(() => {
        window.location.href = "login.html";
    }, 1500);
});
