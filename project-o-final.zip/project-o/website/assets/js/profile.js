/**
 * Halaman profil: menampilkan data pemain yang sedang login.
 */
async function loadProfile() {
    const { data: sessionData } = await supabaseClient.auth.getSession();
    const session = sessionData.session;

    if (!session) {
        window.location.href = "login.html";
        return;
    }

    const user = session.user;

    const { data: profile, error } = await supabaseClient
        .from("profiles")
        .select("username, display_name")
        .eq("id", user.id)
        .single();

    if (error) {
        console.error("Profile error:", error);
        return;
    }

    document.getElementById("username").textContent = profile.username || "-";
    document.getElementById("displayName").textContent =
        profile.display_name || "-";
    document.getElementById("email").textContent = user.email;
}

loadProfile();
