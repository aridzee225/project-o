/**
 * Konfigurasi Supabase.
 *
 * Catatan: nilai di bawah adalah *publishable key* yang memang ditujukan
 * untuk dipakai di sisi browser. Keamanan data tetap bergantung pada
 * Row Level Security (RLS) di Supabase. Jangan pernah menaruh
 * service_role key di file ini.
 */
const SUPABASE_URL = "https://lwsplwlfxidasnfxrust.supabase.co";
const SUPABASE_KEY = "sb_publishable_ras2xc-LyUc9zvr6pJVivw_42IfltjB";
