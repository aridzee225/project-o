/**
 * Perilaku navbar: buka/tutup menu dropdown dan logout.
 * Dipakai oleh semua halaman yang memiliki navbar.
 */
document.addEventListener("DOMContentLoaded", () => {
    const menuToggle = document.getElementById("menuToggle");
    const menuDropdown = document.getElementById("menuDropdown");
    const logoutBtn = document.getElementById("logoutBtn");

    if (!menuToggle || !menuDropdown) {
        return;
    }

    // Buka / tutup menu
    menuToggle.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        menuDropdown.classList.toggle("show");
    });

    // Klik di dalam dropdown tidak menutup menu
    menuDropdown.addEventListener("click", (event) => {
        event.stopPropagation();
    });

    // Klik di luar dropdown menutup menu
    document.addEventListener("click", () => {
        menuDropdown.classList.remove("show");
    });

    // Logout
    if (logoutBtn) {
        logoutBtn.addEventListener("click", async (event) => {
            event.preventDefault();
            event.stopPropagation();

            const { error } = await supabaseClient.auth.signOut();

            if (error) {
                alert("Gagal logout: " + error.message);
                return;
            }

            window.location.href = "login.html";
        });
    }
});
