/**
 * Membuat satu instance Supabase client yang dipakai bersama oleh semua halaman.
 * Harus dimuat setelah library Supabase CDN dan supabase-config.js.
 */
const supabaseClient = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);
