# PROJECT O

Platform website untuk memainkan **board game digital** bersama teman. Setiap game menjadi bagian dari platform dan dapat ditambahkan tanpa mengubah keseluruhan sistem. Game pertama yang dikembangkan adalah **Werewolf**.

> **Status:** Development

---

## Daftar Isi

- [Tujuan Project](#tujuan-project)
- [Struktur Project](#struktur-project)
- [Menjalankan Project](#menjalankan-project)
- [Tim](#tim)
- [Teknologi](#teknologi)
- [Dokumentasi](#dokumentasi)

---

## Tujuan Project

1. Membuat website sebagai wadah berbagai board game.
2. Mengembangkan board game yang dapat dimainkan secara digital.
3. Menyusun struktur project yang memudahkan penambahan game baru.
4. Menggunakan GitHub dan Git sebagai pusat pengelolaan source code.
5. Membagi tanggung jawab pengembangan agar pengerjaan lebih terorganisir.

---

## Struktur Project

```text
PROJECT-O/
├── docs/                  # Dokumentasi project
│   ├── BLUEPRINT.md
│   ├── PEMBAGIAN-TUGAS.md
│   └── ATURAN-DEVELOPMENT.md
│
├── website/               # Platform website (static)
│   ├── index.html         # Home
│   ├── games.html         # Daftar game
│   ├── werewolf.html      # Halaman game Werewolf
│   ├── login.html
│   ├── register.html
│   ├── profile.html
│   └── assets/
│       ├── css/           # style.css, login.css
│       └── js/            # Konfigurasi Supabase, auth, navbar, dan logika halaman
│
└── games/
    └── werewolf/          # Game Werewolf (React + Express + Socket.IO)
```

---

## Menjalankan Project

### Website

Website berupa file statis, jadi cukup dibuka lewat static server.

**Dengan VS Code:** pasang ekstensi _Live Server_, lalu klik **Go Live**. Root sudah diatur ke folder `website` pada `.vscode/settings.json`.

**Dengan terminal:**

```bash
npx serve website
```

Autentikasi dan data profil memakai **Supabase**. Konfigurasi ada di `website/assets/js/supabase-config.js`. Pastikan Row Level Security (RLS) aktif pada tabel `profiles`.

### Game Werewolf

Membutuhkan Node.js.

```bash
cd games/werewolf
npm install
npm run dev
```

Game berjalan di `http://localhost:3000`. Detail fitur dan cara integrasi akun ada di [`games/werewolf/README.md`](games/werewolf/README.md).

Perintah lain:

| Perintah        | Fungsi                                   |
| --------------- | ---------------------------------------- |
| `npm run build` | Build frontend dan server untuk produksi |
| `npm start`     | Menjalankan hasil build                  |
| `npm test`      | Menjalankan unit test                    |
| `npm run lint`  | Pengecekan tipe TypeScript               |

---

## Tim

| Anggota  | Tanggung Jawab                 | Branch                 |
| -------- | ------------------------------ | ---------------------- |
| **Adit** | Website dan platform Project O | `feature/website-adit` |
| **Aji**  | Pengembangan game Werewolf     | `feature/werewolf-aji` |

Setiap anggota mengerjakan bagiannya sendiri dan saling me-review hasil kerja satu sama lain sebelum digabungkan ke `main`.

---

## Teknologi

- **Website:** HTML, CSS, JavaScript, Supabase (autentikasi dan profil)
- **Werewolf:** React, Vite, Tailwind CSS, Node.js, Express, Socket.IO
- **Tools:** Visual Studio Code, Git, GitHub

---

## Dokumentasi

| Dokumen                                          | Isi                                 |
| ------------------------------------------------ | ----------------------------------- |
| [Blueprint](docs/BLUEPRINT.md)                   | Rancangan dan struktur project      |
| [Pembagian Tugas](docs/PEMBAGIAN-TUGAS.md)       | Tanggung jawab tiap anggota         |
| [Aturan Development](docs/ATURAN-DEVELOPMENT.md) | Alur Git, commit, review, dan merge |
